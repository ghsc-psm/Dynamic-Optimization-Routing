import sqlalchemy
import os
import pandas as pd
import getpass
from datetime import datetime
from cryptography.fernet import Fernet


def decrypt(token: str) -> str:
    """ Decrypt a token to a string, such as password

    Args:
        token (str): encrypted string

    Returns:
        str: decrypted secret
    """
    return Fernet(b'w1H5dpTLxB59Nkr4srr3qssEUlCKGEzLD9sHIO85EFI=').decrypt(token.encode('utf-8')).decode('utf-8')


def encrypt(secret: str) -> str:
    """ Encrypt a secret to a token

    Args:
        secret (str): secret to be encrypted

    Returns:
        str: encrypted token
    """
    return Fernet(b'w1H5dpTLxB59Nkr4srr3qssEUlCKGEzLD9sHIO85EFI=').encrypt(secret.encode('utf-8')).decode('utf-8')


def get_opex_db_engine(usr: str = None, pss: str = None) -> sqlalchemy.engine.Engine:
    """ Get SQLAlchemy database engine object to the Azure OPEX Database

    Args:
        usr (str): user name to connect to the database, ignored if either usr or pss not supplied. Use OPEX_DB_USER from the environment variable
        pss (str): encrypted password to connect to the database, ignored if either usr or pss not supplied. Use OPEX_DB_PASS from the environment variable

    Returns:
        sqlalchemy.engine.Engine: the engine object
    """
    if usr is None or pss is None:
        conn_str = f"mssql+pyodbc://{os.environ['OPEX_DB_USER']}:{decrypt(os.environ['OPEX_DB_PASS'])}@psm-report.database.windows.net:1433/PSM-ENHANCED_REPORTING?driver=ODBC+Driver+17+for+SQL+Server"
    else:
        conn_str = f"mssql+pyodbc://{usr}:{decrypt(pss)}@psm-report.database.windows.net:1433/PSM-ENHANCED_REPORTING?driver=ODBC+Driver+17+for+SQL+Server"
    return sqlalchemy.create_engine(conn_str, fast_executemany=True)


def get_artmis_db_engine(usr: str = None, pss: str = None) -> sqlalchemy.engine.Engine:
    """ Get SQLAlchemy database engine object to the ARTMIS Database

    Args:
        usr (str): user name to connect to the database, ignored if either usr or pss not supplied. Use ARTMIS_DB_USER from the environment variable
        pss (str): encrypted password to connect to the database, ignored if either usr or pss not supplied. Use ARTMIS_DB_PASS from the environment variable

    Returns:
        sqlalchemy.engine.Engine: the engine object
    """
    if usr is None or pss is None:
        conn_str = f"db2+ibm_db://{os.environ['ARTMIS_DB_USER']}:{decrypt(os.environ['ARTMIS_DB_PASS'])}@10.158.69.13:50030/ODSPRD"
    else:
        conn_str = f"db2+ibm_db://{usr}:{decrypt(pss)}@10.158.69.13:50030/ODSPRD"
    return sqlalchemy.create_engine(conn_str)


def load_df(df: pd.DataFrame, eng: sqlalchemy.engine.Engine, name: str, schema: str, if_exists: {'fail', 'replace', 'append'}='fail', log: bool = True, comment: str = None):
    """ Load a dataframe to database

        This function simplies the regular data uploads and updates the log table.

    Args:
        df (pd.DataFrame): dataframe to be loaded into the database
        eng (sqlalchemy.engine.Engine): sqlalchemy database engine
        name (str): table name to load data into
        schema (str): the name of the schema for the table
        if_exists (str, optional): {'fail', 'replace', 'append'} action if table exists. Defaults to 'fail'.
        log (bool, optional): whether to insert a log record. Defaults to True.
        comment (str, optional): comments for the data upload. Defaults to None.
    """
    chunksize = min(df.shape[0], 10000)
    df.to_sql(con=eng, name=name, schema=schema, if_exists=if_exists, chunksize=chunksize, index=False)
    if log:
        log_df = pd.DataFrame([[schema.lower(), name.upper(), df.shape[0], getpass.getuser().lower(), datetime.now(), comment]],
                              columns=['SCHEMA', 'TABLE', 'RECORDS', 'UPLOAD_BY', 'UPLOAD_TIME', 'COMMENT'])
        log_df.to_sql(con=eng, name='LOG_DATA_LOAD', schema='opex', if_exists='append', index=False)


def db_table_data(engine: sqlalchemy.engine.Engine, table_name: str, where: [None, str] = None, cols: [None, list] = None) -> pd.DataFrame:
    """
    Pull table from current sql engine connection.

    Args:
        table_name (str): sql table to be pulled
        where (None, str): conditional logic on query
        cols (None, list): columns to filter on
    Returns:
        pd.DataFrame: Converts sql table to pandas dataframe
    """

    cols = '*' if cols is None else ", ".join(cols)
    where = '' if where is None else f"WHERE {where}"
    sql = f'SELECT {cols} FROM {table_name} {where}'

    df = pd.read_sql_query(sql, engine)

    return df
