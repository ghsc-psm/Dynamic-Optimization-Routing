import pickle
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from openpyxl import load_workbook
from openpyxl.utils import get_column_interval
import numpy as np
from pandas.api.types import is_datetime64_any_dtype as is_datetime
import json
import datetime
import pandas as pd
from pprint import pprint
import sys
import re


# scope determines prilvedges - in this case, read and write
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']


class GoogleSheetsSession:
    """
    Google Sheets Agent

    Encapsulates Google Sheet Read/Write Functionalities
    """

    def __init__(self, link_to_google_sheets):
        """ Constructor

        Arg(s):
            link_to_google_sheets (str): Raw http link to Google Sheets page
        """
        # store service object to use when calling api functionality on a Google Sheet
        self.service = self.__authenticate()
        # store spreadsheet ID of given google sheet link. This can be found at the end of the url link, after 'gid='
        self.spreadsheet_id = self._get_id_from_link(link_to_google_sheets)
        # store list of WRITE updates so that they can all be called in a batch update (this is done because Google Sheets API only allows 100 API calls/100 Seconds for each user.)
        self.batch_write_values = {'data': [] }
        # store list of FORMAT updates so that they can all be called in a batch update (this is done because Google Sheets API only allows 100 API calls/100 Seconds for each user.)
        self.batch_format_values = {'requests': [] }
        # store dictinary to map Google Sheet column to index
        self.excel_columns_dict = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7, 'I': 8, 'J': 9, 'K': 10,
               'L': 11, 'M': 12, 'N': 13, 'O': 14, 'P': 15, 'Q': 16, 'R': 17, 'S': 18, 'T': 19, 'U': 20,'V': 21,
               'WW': 22, 'X': 23, 'Y': 24, 'Z': 25, 'AA': 26, 'AB': 27, 'AC': 28, 'AD': 29, 'AE': 30, 'AF': 31, 'AG': 32}

    ###
    # HELPER FUNCTIONS
    ###

    def __check_series_for_date(self, series):
        """ Helper function to check if a series object has any date values.

        Args:
            series: Pandas series object.
        Returns:
            bool: True if date value is present in series. Otherwise, False
        """
        return(series.apply(lambda value: isinstance(value, datetime.datetime) or isinstance(value, datetime.date))).any()

    def __get_cell_range_indexes(self, cell_range):
        """ Helper function to get the row and column index of a given cell range.

        Args:
            cell_range (str): Specific range to be replaced - format 'StartCell:EndCell'
        Returns:
            startRowIndex: Start index value of row range
            endRowIndex: End indec value of row range
            startColumnIndex: Start index value of column range. Ex: A --> 0, B --> 1
            endColumnIndex: End index value of row column. Ex: A --> 0, B --> 1
        """
        startRowIndex = int(cell_range.split(':')[0][1:])
        endRowIndex = int(cell_range.split(':')[1][1:])
        startColumnIndex = self.excel_columns_dict[cell_range.split(':')[0][0]]
        endColumnIndex = self.excel_columns_dict[cell_range.split(':')[1][0]]

        return startRowIndex, endRowIndex, startColumnIndex, endColumnIndex

    # done
    def __authenticate(self):
        """ Helper function to authenticate a user's google account. Automatically called as part of __init__

        Returns:
            service: Connection object to access sheets api
        """
        creds = None

        # if the pickle file exists then user has logged in prior
        if os.path.exists('token.pickle'):
            with open('token.pickle', 'rb') as token:
                creds = pickle.load(token)
        # Force login if credentials don't exist
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    'credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)
            # create file to bypass login for next use
            with open('token.pickle', 'wb') as token:
                pickle.dump(creds, token)

        service = build('sheets', 'v4', credentials=creds, cache_discovery=False)
        return service

    # done
    def _get_id_from_link(self, link_to_google_sheets):
        """ Helper function extract the Sheet ID from a Google Sheets http link.

        Args: 
            link_to_google_sheets (str): Raw http link to Google Sheets page.

        Returns:
            spreadsheet_id: Google Sheets Spreadsheet ID
        """
        # extract the sheet id from given URL using regex
        identifier = link_to_google_sheets
        spreadsheet_identifier = re.search('/spreadsheets/d/([a-zA-Z0-9-_]+)', identifier)
        spreadsheet_id = spreadsheet_identifier.group(1)

        return spreadsheet_id

    ###
    # READING/SAVING FUNCTIONS
    ###

    def read_sheets(self):
        """ Reads content of google sheets file

        Returns:
            ssData: List of dictionaries. Dictionaries containt both metadata and values for each sheet in Google Sheets
            titles: List of strings. Strings represent the sheet names within the Google Sheet
        """

        # fetch properties of all sheets
        ssReq = self.service.spreadsheets().get(
            spreadsheetId=self.spreadsheet_id, fields="sheets.properties")
        ssRes = ssReq.execute()
        sheetsInfo = ssRes.get('sheets')
        titles = []

        # loop over sheet names and append to titles list
        for sheet in sheetsInfo:
            titles.append(sheet.get('properties').get('title'))

        # get data from all sheets using titles as range
        resultInput = self.service.spreadsheets().values().batchGet(
            spreadsheetId=self.spreadsheet_id, ranges=titles, valueRenderOption='UNFORMATTED_VALUE',
            dateTimeRenderOption='FORMATTED_STRING').execute()

        ssData = resultInput.get('valueRanges')

        return ssData, titles

    def get_sheet_df(self, sheet_name, skip_rows=0):
        """ Reads content of Google Sheets Speadsheet and returns a Pandas DataFrame

        Args: 
            sheet_name (str):name of Google Sheet Tab
            skip_rows (str): (optional) number of rows to skip when reading in data
        """
        # get data and title names for each sheet
        ssData, titles = self.read_sheets()

        # loop over each sheet
        for i, sheet in enumerate(ssData):
            # get data
            valuesInput = sheet.get('values')
            # convert to pandas df
            df = pd.DataFrame(valuesInput)
            # first row of df will be col names
            df.columns = df.iloc[0 + skip_rows]
            # drop first row, which is the column names, after we set column names
            df = df[1 + skip_rows:]
            # if sheet is the sheet we are searching for, return dataframe
            if titles[i] == sheet_name:
                return df

    
    def save_sheets(self, output_fname):
        """ Reads content of Google Sheets Speadsheet and saves as Excel Workbook

        Args: 
            output_fname (str): Desired name of output file
        """

        output_file = output_fname
        # open write object
        writer = pd.ExcelWriter(os.path.join(os.pardir, output_file))
        # get data and title names for each sheet
        ssData, titles = self.read_sheets()

        # set counter
        i = 0
        # loop over each set of data
        for sheet in ssData:
            # get data
            valuesInput = sheet.get('values')
            # convert data to df
            df = pd.DataFrame(valuesInput)
            # get title
            tempTitle = titles[i]
            # restriction on sheet titles > 31 char
            if len(tempTitle) > 31:
                tempTitle = tempTitle[:30]
            # add df to writer
            df.to_excel(writer, sheet_name=tempTitle, index=False,
                        index_label=False, header=False)
            i += 1
        writer.save()


    ###
    # WRITING & CALLING API FUNCTIONS
    ###

    def write_sheet(self, local_fname, local_worksheet, google_sheet_name, cell_range=None, date_format='%d-%b-%Y'):
        """ Writes contents of single sheet of excel file to google sheets

        Args: 
            local_fname (str): name of local excel file - should be in same directory
            local_worksheet (str): worksheet of excel file to extract data from
            google_sheet_name (str): name of google sheet to be written to
            cell_range (str): (optional) specific range to be replaced - format 'StartCell:EndCell'
            date_format (str): (optional) format for all date values
        """
        excel_file_name = local_fname
        excel_file_sheet = local_worksheet

        # if cell range is not none, add sheet name in front of cell range to ensure data is placed on the right sheet
        if cell_range is not None:
            # concat sheetname and cell range
            sheet_range = google_sheet_name + "!" + cell_range
        else:
            sheet_range = google_sheet_name

        # read entire sheet into dataframe
        xl = pd.ExcelFile(excel_file_name)
        df = xl.parse(excel_file_sheet)

        # convert dates to string
        for col in [column for column in df.columns if self.__check_series_for_date(df[column])]:
            df[col] = df[col].dt.strftime(date_format)

        df = df.replace(np.nan, '', regex=True)

        # range unspec means we update the entire sheet
        data = [df.columns.values.tolist()] + df.values.tolist()

        body = {
            'values': data
        }

        result = self.service.spreadsheets().values().update(spreadsheetId=self.spreadsheet_id, valueInputOption='RAW', range=sheet_range, body=body
        ).execute()

    def write_df(self, dataframe, google_sheet_name, cell_range=None, date_format='%d-%b-%Y', include_header=True):
        """ Writes contents of single sheet of excel file to google sheets

        Args: 
            dataframe (dataframe): dataframe of data to write to Google Sheets
            google_sheet_name (str): name of Google Sheet to be written to
            cell_range (str): (optional) specific range to be replaced - format 'StartCell:EndCell'
            date_format (str): (optional) format for all date values
            include_header (bool): (optional) whether or not to include the header (col names) of the dataframe
        """
        # if cell range is not none, add sheet name in front of cell range to ensure data is placed on the right sheet
        if cell_range is not None:
            sheet_name = google_sheet_name + '!' + cell_range
        else:
            sheet_name = google_sheet_name

        df = dataframe.copy()

        # convert dates to string
        for col in [column for column in df.columns if self.__check_series_for_date(df[column])]:
            try:
                df[col] = df[col].dt.strftime(date_format)
            except:
                df[col] = df[col].apply(lambda date_val: date_val.strftime(date_format) if not pd.isnull(date_val) else '')

        df = df.replace(np.nan, '', regex=True)

        if include_header == True:
            # include header of dataframe 
            data = [df.columns.values.tolist()] + df.values.tolist()
        else:
            # only extract values from dataframe
            data = df.values.tolist()

        body = {
            'values': data
        }

        result = self.service.spreadsheets().values().update(
            spreadsheetId=self.spreadsheet_id, valueInputOption='RAW', range=sheet_name, body=body
        ).execute()

    def highlight_cells(self, spreadsheet_id, cell_range, red, green, blue):
        """ Highlights cells within a given range with the given RGB color.
            PLEASE NOTE, Google Sheets API only allows 100 API calls/100 Seconds for each user.
            If you'd like to make many updates, please use the add_highlight_batch_update() function
            to build a dictionary of updates, and then call batch_update_format_values() to do a batch
            update. This results in 1 API call instead of many smaller ones. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'
            red (int): Intensity of red color (integer between 0 and 255)
            green (int): Intensity of green color (integer between 0 and 255)
            blue (int): Intensity of blue color (integer between 0 and 255)
        """
        # extract index of row and cols
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        # build update body
        batch_update_spreadsheet_request_body = {
            "requests": [
                {
                    "repeatCell": {
                        "range": {
                            "sheetId": spreadsheet_id,
                            "startRowIndex": startRowIndex - 1,
                            "endRowIndex": endRowIndex,
                            "startColumnIndex": startColumnIndex,
                            "endColumnIndex": endColumnIndex + 1
                        },
                        "cell": {
                            "userEnteredFormat": {
                                "backgroundColor": {
                                    "red": red/255,
                                    "green": blue/255,
                                    "blue": green/255,
                                    "alpha": 0.01
                                }
                            }
                        },
                        "fields": "userEnteredFormat.backgroundColor"
                    }
                }
            ]
        }

        # build request
        request = self.service.spreadsheets().batchUpdate(spreadsheetId=self.spreadsheet_id, body=batch_update_spreadsheet_request_body)
        # execute request
        res = request.execute()

    # done
    def write_value(self, sheet_name, cell, value):
        """ 
        Writes contents of single cell value to Google Sheets
        PLEASE NOTE, Google Sheets API only allows 100 API calls/100 Seconds for each user.
        If you'd like to make many updates, please use the add_write_batch_update() function
        to build a dictionary of updates, and then call batch_update_write_values() to do a batch
        update. This results in 1 API call instead of many smaller ones. 

        Args:
            sheet_name (str): name of Google Sheet Tab
            cell (str): provide specific range to be replaced - format 'StartCell:EndCell'
            value (str, int, float, date, ...): value you would like to save to Google Sheets Cell
        """
        # add sheet name in front of cell range to ensure data is placed on the right sheet
        cell_range = sheet_name + "!" + cell + ':' + cell

        body = {
            'values': [[value]]
        }

        result = self.service.spreadsheets().values().update(
            spreadsheetId=self.spreadsheet_id, valueInputOption='RAW', range=cell_range, body=body
        ).execute()

    # 
    def format_cell_as_date(self, spreadsheet_id, cell_range, date_pattern='dd-mm-YYYY'):
        """ Apply a date format to cells within a given range.
            PLEASE NOTE, Google Sheets API only allows 100 API calls/100 Seconds for each user.
            If you'd like to make many updates, please use the add_highlight_batch_update() function
            to build a dictionary of updates, and then call batch_update_format_values() to do a batch
            update. This results in 1 API call instead of many smaller ones. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'
            date_format (str): (optional) format for all date values
        """
        # extract index of row and cols
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        requests = [
                {
                    'repeatCell':
                    {
                        "range": {
                            "sheetId": spreadsheet_id,
                            "startRowIndex": startRowIndex - 1,
                            "endRowIndex": endRowIndex,
                            "startColumnIndex": startColumnIndex,
                            "endColumnIndex": endColumnIndex + 1
                        },
                        'cell':
                        {
                            "userEnteredFormat":
                            {
                                "numberFormat":
                                {
                                    "type": "DATE",
                                    "pattern": date_pattern
                                }
                            }
                        },
                        'fields': 'userEnteredFormat.numberFormat'
                    }
                }
            ]
        body = {"requests": requests}
        response = self.service.spreadsheets().batchUpdate(spreadsheetId=self.spreadsheet_id, body=body).execute()

    ###
    # WRITING & BUILDING BATCHES BEFORE CALLING API FUNCTIONS
    ###

    def add_highlight_batch_update(self, spreadsheet_id, cell_range, red, blue, green):
        """ Add a highlight update to batch of updates.
            PLEASE NOTE, you must call the batch_update_format_values() actually send the updates to the Google API. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'
            red (int): Intensity of red color (integer between 0 and 255)
            green (int): Intensity of green color (integer between 0 and 255)
            blue (int): Intensity of blue color (integer between 0 and 255)
        """
        # extract index of row and cols
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        request = {
                    "repeatCell": {
                        "range": {
                            "sheetId": spreadsheet_id,
                            "startRowIndex": startRowIndex - 1,
                            "endRowIndex": endRowIndex,
                            "startColumnIndex": startColumnIndex,
                            "endColumnIndex": endColumnIndex + 1
                        },
                        "cell": {
                            "userEnteredFormat": {
                                "backgroundColor": {
                                    "red": red/255,
                                    "green": blue/255,
                                    "blue": green/255,
                                    "alpha": 0.01
                                }
                            }
                        },
                        "fields": "userEnteredFormat.backgroundColor"
                    }
                }

        self.batch_format_values['requests'].append(request)
        

    def add_value_format_batch_update(self, spreadsheet_id, cell_range, format_type, cell_format):
        """ Add a cell format update to batch of updates.
            PLEASE NOTE, you must call the batch_update_format_values() actually send the updates to the Google API. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'
            format_type (str): Format type for all values (ex: 'DATE')
            cell_format (str): Format for all values (ex: 'dd-mmm-yyyy')
        """
        # extract index of row and cols
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        request = {
                    "repeatCell": {
                        "range": {
                            "sheetId": spreadsheet_id,
                            "startRowIndex": startRowIndex - 1,
                            "endRowIndex": endRowIndex,
                            "startColumnIndex": startColumnIndex,
                            "endColumnIndex": endColumnIndex + 1
                        },
                        "cell": {
                            "userEnteredFormat": {
                                "numberFormat":
                                {
                                    "type": format_type,
                                    "pattern": cell_format
                                }
                            }
                        },
                        'fields': 'userEnteredFormat.numberFormat'
                    }
                }

        self.batch_format_values['requests'].append(request)
        
    
    def add_write_batch_update(self, sheet_name, cell_range, value):
        """ Apply a date format to cells within a given range.
           PLEASE NOTE, you must call the batch_update_write_values() actually send the updates to the Google API. 

        Args:
            sheet_name (str): Name of Google Sheet Tab
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'
            value (str, int, float, date, ...): Value you would like to save to Google Sheets Cell
        """
        # add sheet name in front of cell range to ensure data is placed on the right sheet
        cell_range = sheet_name + "!" + cell_range

        data = {
            "range": cell_range,
            "values": [[value]]
            }

        self.batch_write_values['data'].append(data)


    def add_alignment_format_batch_update(self, spreadsheet_id, cell_range, horizontal_alignment='LEFT', vertical_alignment='MIDDLE', font='Calibri', font_size=11):
        """ Add a cell alignment update to batch of updates.
            PLEASE NOTE, you must call the batch_update_format_values() actually send the updates to the Google API. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'
            horizontal_alignment (str): Vertical alignment of data --> Default is 'LEFT'
            vertical_alignment (str): Vertical alignment of data --> Default is 'MIDDLE'
            font (str): (optional) Font type of data --> Default is Calibri
            font_size (int): (optional) Font size of data --> Default is 11
        """

        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        request = {
                    'repeatCell': {
                        'cell': {
                        'userEnteredFormat': {
                            'horizontalAlignment': horizontal_alignment,
                            'verticalAlignment': vertical_alignment,
                            'textFormat': {'fontFamily': font,
                                        'fontSize': font_size}

                        }
                        },
                        'range': {
                        "sheetId": spreadsheet_id,
                        'startRowIndex': startRowIndex - 1,
                        'endRowIndex': endRowIndex,
                        'startColumnIndex': startColumnIndex,
                        'endColumnIndex': endColumnIndex + 1
                        },
                        'fields': "userEnteredFormat"
                    }
                    }

        self.batch_format_values['requests'].append(request)


    def __add_protected_range(self, cell_range, range_id, description):
    # TODO HIDDEN FUNCTION BECAUSE STIL IN PROGRESS
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        request = {
                "addProtectedRange": {
                    "protectedRange": {
                        "protectedRangeId": range_id,
                        "range": {
                            "startRowIndex": startRowIndex - 1,
                            "endRowIndex": endRowIndex,
                            "startColumnIndex": startColumnIndex,
                            "endColumnIndex": endColumnIndex + 1
                        },
                        "description": description,
                        "warningOnly": False,
                    }
                }
            }

        self.batch_format_values['requests'].append(request)


    def __delete_protected_range(self, range_id):
        # TODO HIDDEN FUNCTION BECAUSE STIL IN PROGRESS
        request = {
            "deleteProtectedRange": {
                "protectedRangeId": range_id
                }
                }

        self.batch_format_values['requests'].append(request)

    def clear_range(self, spreadsheet_name, cell_range):
        """ Clears values of specified range.

        Args: 
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'.
        """
        # add sheet name in front of cell range to ensure data is placed on the right sheet
        sheet_range = spreadsheet_name + '!' + cell_range

        clear_values_request_body = {}

        request = self.service.spreadsheets().values().clear(spreadsheetId=self.spreadsheet_id, range=sheet_range, body=clear_values_request_body)
        response = request.execute()


    def add_border_format_batch_update(self, spreadsheet_id, cell_range, style='SOLID'):
        """ Add a cell border update to batch of updates.
            PLEASE NOTE, you must call the batch_update_format_values() actually send the updates to the Google API. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='.
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'.
            style (str): Border style applied to each cell. --> Default value is 'SOLID'.
        """
        # extract index of row and cols
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        request = {
                "updateBorders": {
                    "range": {
                        'sheetId': spreadsheet_id,
                        'startRowIndex': startRowIndex - 1,
                        'endRowIndex': endRowIndex,
                        'startColumnIndex': startColumnIndex,
                        'endColumnIndex': endColumnIndex + 1
                    },
                    "top": {
                    "style": style,
                    "width": 1,
                    #"color": color,
                    },
                    "bottom": {
                    "style": style,
                    "width": 1,
                    #"color": color,
                    },
                    "left": {
                    "style": style,
                    "width": 1,
                    #"color": color,
                    },
                    "right": {
                    "style": style,
                    "width": 1,
                    #"color": color,
                    },
                }
            }

        self.batch_format_values['requests'].append(request)


    def add_wrap_text_batch_update(self, spreadsheet_id, cell_range, wrap_strategy='WRAP'):
        """ Add a wrap text update to batch of updates.
            PLEASE NOTE, you must call the batch_update_format_values() actually send the updates to the Google API. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='.
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'.
            wrap_strategy (str): Wrap strategy applied to each cell. --> Default value is 'WRAP'.
        """
        # extract index of row and cols
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        request = {
            'repeatCell': {
                'cell': {
                'userEnteredFormat': {
                    "wrapStrategy": wrap_strategy
                }
                },
                'range': {
                'sheetId': spreadsheet_id,
                'startRowIndex': startRowIndex - 1,
                'endRowIndex': endRowIndex,
                'startColumnIndex': startColumnIndex,
                'endColumnIndex': endColumnIndex + 1
                },
                'fields': "userEnteredFormat.wrapStrategy"
            }
            }

        self.batch_format_values['requests'].append(request)


    def add_number_format_update(self, spreadsheet_id, cell_range, number_format, number_pattern=None, horizontal_alignment='LEFT', vertical_alignment='MIDDLE'):
        """ Add a cell format update to batch of updates.
            PLEASE NOTE, you must call the batch_update_format_values() actually send the updates to the Google API. 

        Args:
            spreadsheet_id (str): Google Sheet ID --> Found at the end of the url link, after 'gid='
            cell_range (str): A specific Google Sheets cell range to be highlighted - format 'StartCell:EndCell'
            number_format (str): Format type for all values (ex: 'CURRENCY', 'DATE')
            number_pattern (str): Format for all values (ex: 'dd-mmm-yyyy') --> Default value is None.
            horizontal_alignment (str): Vertical alignment of data --> Default is 'LEFT'
            vertical_alignment (str): Vertical alignment of data --> Default is 'MIDDLE'
        """
        # extract index of row and cols
        startRowIndex, endRowIndex, startColumnIndex, endColumnIndex = self.__get_cell_range_indexes(cell_range)

        request = {
                    'repeatCell': {
                        'cell': {
                        'userEnteredFormat': {
                            'horizontalAlignment': horizontal_alignment,
                            'verticalAlignment': vertical_alignment,
                            'numberFormat': {'type': number_format}

                        }
                        },
                        'range': {
                        'sheetId': spreadsheet_id,
                        'startRowIndex': startRowIndex - 1,
                        'endRowIndex': endRowIndex,
                        'startColumnIndex': startColumnIndex,
                        'endColumnIndex': endColumnIndex + 1
                        },
                        'fields': "userEnteredFormat"
                    }
                    }
        # if a number pattern is provided, pass into body of request
        if number_pattern:
            request['repeatCell']['cell']['userEnteredFormat']['numberFormat']['pattern'] = number_pattern

        self.batch_format_values['requests'].append(request)

    ###
    # SUBMIT BATCH UPDATES FUNCTIONS
    ###

    def batch_update_write_values(self):
        """ Send batch of write updates to Google Sheets API
        """
        # check if there are any updates to be made
        if len(self.batch_write_values['data']) > 0:
            # if updates, add Value Input Option for API call
            self.batch_write_values["valueInputOption"] = "RAW"
            # build request to batch updates values
            request = self.service.spreadsheets().values().batchUpdate(spreadsheetId=self.spreadsheet_id, body=self.batch_write_values)
            # submit request
            response = request.execute()

    def batch_update_format_values(self):
        """ Send batch of format updates to Google Sheets API
        """
        # check if there are any updates to be made
        if len(self.batch_format_values['requests']) > 0:
            # build request to batch updates format values
            request = self.service.spreadsheets().batchUpdate(spreadsheetId=self.spreadsheet_id, body=self.batch_format_values)
            # submit request
            response = request.execute()