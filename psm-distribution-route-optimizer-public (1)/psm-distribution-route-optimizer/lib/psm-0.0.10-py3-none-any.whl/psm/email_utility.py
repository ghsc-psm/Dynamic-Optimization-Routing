
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from psm.db import decrypt
import os


class EmailAgent(object):
    """ Class Email Agent

    Encapsulate email functionalities
    """

    def __init__(self, sender_acct, sender_pass, sender_email=None):
        """ Constructor

        Args:
            sender_acct (str): account name to log into the email service.
            sender_pass (str): account password to log into the email service
            sender_email (str, optional): if different from sender_acct, the email address to send email from
        """
        self.sender_acct = sender_acct
        self.sender_pass = sender_pass
        self.sender_email = sender_email if sender_email is not None else sender_acct

    def send(self, to_emails, subject, body, cc_emails=None, bcc_emails=None, msg_type='plain', attach_list=None, attach_file = None):
        """
        builds the message, Connects to a mail server and sends a email

        Args:
            to_emails (str): receiving email, if multiple, separated by semicolon.
            subject (str): subject of the email
            body (str): body of the email
            cc_emails (str, optional): cc'ed email, if multiple, separated by semicolon
            msg_type(str, optional): type messages, plain or html. default to html
        """

        msg = MIMEMultipart()
        msg['FROM'] = self.sender_email
        msg['SUBJECT'] = subject
        msg['TO'] = to_emails

        if cc_emails is not None:
            msg['CC'] = cc_emails

        if bcc_emails is not None:
            msg['BCC'] = bcc_emails

        msg.attach(MIMEText(body, msg_type))
        if attach_list is not None:
            msg = self.attach_files(msg, attach_list)
        if attach_file is not None:
            msg = self.attach_files(msg, [attach_file])

        s = smtplib.SMTP(host='smtp-mail.outlook.com', port=587)
        s.starttls()
        s.login(self.sender_acct, decrypt(self.sender_pass))
        s.send_message(msg)

    def attach_files(self, msg, attach_list):
        #attach attachments
        for at in attach_list:
            if at is not None:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(open(at,"rb").read())
                encoders.encode_base64(part)
                fn = os.path.basename(at)
                part.add_header('Content-Disposition','attachment; filename="%s"'% fn)
                msg.attach(part)
        return msg

if __name__ == '__main__':

    import os
    em = EmailAgent(os.environ['PSM_USER'], os.environ['PSM_PASS'])
    text_msg = """
    In this HTML tutorial, you will find more than 200 examples. With our online "Try it Yourself" editor,
    you can edit and test each example yourself!

    At W3Schools you will find complete references about HTML elements, attributes, events, color names,
    entities, character-sets, URL encoding, language codes, HTTP messages, browser support, and more
    """

    html_msg = """
    <h1>Welcome to <a href="https://opexapp.azurewebsites.net/">OPEX Toolkit</a></h1>

    <p>You will find it to be easy to use.</p>
    <p>Send <a href="mailto:hni@ghsc-psm.org">us</a> your <b>feedback and suggestion</b>.</p>
    """
    
    #em.send('huani@us.ibm.com', 'PSM Test html', html_msg, cc_emails='hni@ghsc-psm.org', msg_type='html')
    #em.send('huani@us.ibm.com', 'PSM Test text', text_msg, cc_emails='hni@ghsc-psm.org')
    fn = "c:\\Users\\DAVIDTEALE\\Downloads\\Product List.xlsx"
    fn2 = 'c:\\Users\\DAVIDTEALE\\Downloads\\Item List.xlsx'
    #em.send('dteale@us.ibm.com', 'PSM Test text', text_msg, cc_emails='', attach_file=fn )
    #em.send('dteale@us.ibm.com', 'PSM Test text', text_msg, cc_emails='', attach_list=[fn,fn2] )
    em.send('', 'PSM Test text', text_msg, cc_emails='', bcc_emails='dteale@us.ibm.com;dteale@ghsc-psm.org',  )