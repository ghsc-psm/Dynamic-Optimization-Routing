import configparser
import logging
import os
import sys

class Env(object):
    """ Class Env

    The Env class seeks to simply the logging and configuration file handling.
    """

    def __init__(self, config_fname: str = None, log_fname: str = None):
        """ Constructor to the Env class

        Args:
            config_fname (str, optional): name of the config file. Defaults to None.
            log_fname (str, optional): name of the log file to write in addition to stdout. Defaults to None.
        """

        self.config = configparser.ConfigParser()
        if config_fname is not None:
            if os.path.isfile(config_fname):
                self.config.read(config_fname)
            else:
                raise ValueError(f"Configuration file ({config_fname}) not found")

        s_level = logging.DEBUG
        s_fmt_str = "%(asctime)s %(levelname)-8s (%(name)s) %(message)s"
        s_dt_str = "%m/%d/%y %H:%M:%S"
        if "ENV" in self.config:
            if "LOG_STREAM_FORMAT" in self.config["ENV"]:
                s_fmt_str = self.config.get("ENV", "LOG_STREAM_FORMAT", raw=True)
            if "LOG_STREAM_LEVEL" in self.config["ENV"]:
                s_level = self.config.getint("ENV", "LOG_STREAM_LEVEL")
        s_formatter = logging.Formatter(fmt=s_fmt_str, datefmt=s_dt_str)

        logging.basicConfig(format=s_fmt_str, datefmt=s_dt_str, level=s_level)
        self.log = logging.getLogger(__name__)

        if log_fname is not None:
            f_fmt_str = s_fmt_str
            f_level = s_level
            if "ENV" in self.config:
                if "LOG_FILE_FORMAT" in self.config["ENV"]:
                    f_fmt_str = self.config.get("ENV", "LOG_FILE_FORMAT", raw=True)
                if "LOG_FILE_LEVEL" in self.config["ENV"]:
                    f_level = self.config.getint("ENV", "LOG_FILE_LEVEL")
            f_formatter = logging.Formatter(fmt=f_fmt_str, datefmt=s_dt_str)

            f_handler = logging.FileHandler(filename=log_fname, mode='w')
            f_handler.setFormatter(f_formatter)
            f_handler.setLevel(level=f_level)
            
            self.log = logging.getLogger(__name__)
            self.log.addHandler(f_handler)
            self.log.critical(f"Log file: {log_fname}; Level: {f_level}; Format: {f_fmt_str}")            
        
        self.log.critical(f"Stream Log; Level: {s_level}; Format: {s_fmt_str}")

    def pretty_log(self, message: str, log_type: str = 'INFO', color: str = None):
        """ Log colored/formated messages to your terimal.

        Args:
            message (str): Message you would like to log.
            log_type (str): Log level of message. Value must be one of the following: 'CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG'"
            color (str): Color/format of message. Value must be one of the following: 'PURPLE', 'BLUE', 'CYAN', 'GREEN', 'YELLOW', 'RED', 'BOLD', 'UNDERLINE'"
        """
        # store dict of colors to be used in log
        color_dct = {'PURPLE': '\033[95m', 'BLUE': '\033[94m', 'CYAN': '\033[96m',
        'GREEN': '\033[92m', 'YELLOW': '\033[93m', 'RED': '\033[91m',
        'BOLD' : '\033[1m', 'UNDERLINE' : '\033[4m', None: ''}

        # create error message variables
        color_error_message = "Incorrect color provided. Value must be one of the following: 'PURPLE', 'BLUE', 'CYAN', 'GREEN', 'YELLOW', 'RED', 'BOLD', 'UNDERLINE'"
        log_type_error_message = "Incorrect log type provided. Value must be one of the following: 'CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG'"

        # assert that hyper-parameters are correct
        assert color in color_dct.keys(), color_error_message
        assert log_type in ['CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG'], log_type_error_message

        # build log message
        log_message = color_dct[color] + f"{message}" + '\033[0m' if color is not None else message

        # execute log message
        if log_type == 'CRITICAL':
            self.log.critical(log_message)

        if log_type == 'ERROR':
            self.log.error(log_message)

        if log_type == 'WARNING':
            self.log.warning(log_message)

        if log_type == 'INFO':
            self.log.info(log_message)

        if log_type == 'DEBUG':
            self.log.debug(log_message)
