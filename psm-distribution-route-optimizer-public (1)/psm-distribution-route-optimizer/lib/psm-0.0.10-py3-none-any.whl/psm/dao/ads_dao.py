'''
Created on Sep 25, 2020

@author: camfulghum
'''

import numpy as np
import pandas as pd

from os.path import dirname, abspath
from typing import Optional, Mapping
from psm.db import get_opex_db_engine, db_table_data
from psm.env import Env

_POW_MAP_PRODUCT_CAT_2_COMMODITY_TEAM = {
    "HIV/AIDS Pharmaceuticals"                        : "ARV",
    "Nutritional Supplements"                         : "RUTF & RUSF",
    "Laboratory Consumables"                          : "Lab",
    "Laboratory Equipment"                            : "Lab",
    "Laboratory Reagents"                             : "Lab",
    "IT Equipment"                                    : "Lab",
    "Vehicles"                                        : "Lab",
    "Others"                                          : "Lab",
    "HIV Rapid Test Kits (RTKs)"                      : "Lab",
    "Office Equipment"                                : "Lab",
    "Other Global Health Commodities"                 : "Lab",
    "Female Condoms"                                  : "Condoms",
    "Male Condoms"                                    : "Condoms",
    "Personal Lubricants"                             : "Condoms",
    "Voluntary Male Circumcision (VMMC) Kits"         : "VMMC",
    "Voluntary Male Circumcision (VMMC) Supplies"     : "VMMC",
    "Essential Medicines"                             : "Essential Medicines",
    "Medical Supplies"                                : "Lab",
    "Malaria Rapid Diagnostic Test (RDTs)"            : "RDTs",
    "Long Lasting Insecticide Treated Nets (LLINs)"   : "LLINs",
    "Malaria Pharmaceuticals"                         : "TO2",
    "Intrauterine Devices"                            : "TO3",
    "Contraceptive Implants"                          : "TO3",
    "Injectable Contraceptives"                       : "TO3",
    "Oral Contraceptives"                             : "TO3",
    "Standard Days Method"                            : "TO3",
    'Warehouse Equipment'                             : 'Lab'
}


class ADS_DAO():
    '''
    Analytics Data Store (ADS) Data Access Object. Utilizes functionality from db.py.
    '''

    def __init__(self):
        '''
        Constructor - Gathers server and database information & executes sql engine function.
                      super() inherits superclass SQL_DB_UTIL constructor methods/attributes.

        Args:
            servername (str): Name of SQL Server
            database (str): Name of Database
        '''

        self.env = self._ads_env_setup()
        self.log = self.env.log

        self.engine = self._db_conn()

        self.orders = None
        self.catalog = None
        self.recipients = None
        self.suppliers = None
        self.status = None
        self.order_shipments = None

    def _ads_env_setup(self):
        '''
        Private function to create config/log environment for ADS_DAO

        Returns:
            env: Env Object
        '''

        root = dirname(abspath(__file__))
        env = Env(None, root + r'/ads_log.log')

        return env

    def _db_conn(self):
        '''
        Private function to establish connection to Azure SQL database

        returns:
            SQLAlchemy.Engine.engine: Connection object
        '''

        engine = get_opex_db_engine()

        return engine

    def get_orders(self) -> pd.DataFrame:
        '''
        Pull Order table from opex SQL database.

        returns:
            pd.DataFrame: Converts sql table to pandas dataframe
        '''

        if self.orders is None:
            self.orders = db_table_data(self.engine, 'opex.ADS_ORDER')
        else:
            self.log.debug('Lazy loading Orders DataFrame...')

        self.log.debug("Retrieving opex.ADS_ORDER...")
        self.log.debug(f"Retrieved opex.ADS_ORDER: {self.orders.shape[0]} rows")

        return self.orders

    def get_catalog(self) -> pd.DataFrame:
        '''
        Pull Catalog table from opex SQL database.

        returns:
            pd.DataFrame: Converts sql table to pandas dataframe
        '''

        if self.catalog is None:
            self.catalog = db_table_data(self.engine, 'opex.ADS_CATALOG')
        else:
            self.log.debug('Lazy loading Orders DataFrame...')

        self.log.debug("Retrieving opex.ADS_CATALOG...")
        self.log.debug(f"Retrieved opex.ADS_CATALOG: {self.catalog.shape[0]} rows")

        return self.catalog

    def get_recipients(self) -> pd.DataFrame:
        '''
        Pull Recipient table from opex SQL database.

        returns:
            pd.DataFrame: Converts sql table to pandas dataframe
        '''

        if self.recipients is None:
            self.recipients = db_table_data(self.engine, 'opex.ADS_RECIPIENT')
        else:
            self.log.debug('Lazy loading recipients DataFrame...')

        self.log.debug("Retrieving opex.ADS_RECIPIENT...")
        self.log.debug(f"Retrieved opex.ADS_RECIPIENT: {self.recipients.shape[0]} rows")

        return self.recipients

    def get_suppliers(self) -> pd.DataFrame:
        '''
        Pull Supplier table from opex SQL database.

        returns:
            pd.DataFrame: Converts sql table to pandas dataframe
        '''

        if self.suppliers is None:
            self.suppliers = db_table_data(self.engine, 'opex.ADS_SUPPLIER')
        else:
            self.log.debug('Lazy loading supplier DataFrame...')

        self.log.debug("Retrieving opex.ADS_SUPPLIER...")
        self.log.debug(f"Retrieved opex.ADS_SUPPLIER: {self.suppliers.shape[0]} rows")

        return self.suppliers

    def get_status(self) -> pd.DataFrame:
        '''
        Pull Status table from opex SQL database.

        returns:
            pd.DataFrame: Converts sql table to pandas dataframe
        '''

        if self.status is None:
            self.status = db_table_data(self.engine, 'opex.ADS_STATUS')
        else:
            self.log.debug('Lazy loading supplier DataFrame...')

        self.log.debug("Retrieving opex.ADS_STATUS...")
        self.log.debug(f"Retrieved opex.ADS_STATUS: {self.status.shape[0]} rows")

        return self.status

    def get_order_shipments(self) -> pd.DataFrame:
        '''
        Pull Order_Shipment table from opex SQL database.
        Automatically converts Date fields to Datetime.

        returns:
            pd.DataFrame: Converts sql table to pandas dataframe
        '''

        if self.order_shipments is None:
            self.order_shipments = db_table_data(self.engine, 'opex.ADS_ORDER_SHIPMENT')

        else:
            self.log.debug('Lazy loading supplier DataFrame...')

        self.log.debug("Retrieving opex.ADS_ORDER_SHIPMENT...")
        self.log.debug(f"Retrieved opex.ADS_ORDER_SHIPMENT: {self.order_shipments.shape[0]} rows")

        return self.order_shipments

    @classmethod
    def get_commodity_team(cls,
                           tlp_ind: str,
                           category: str,
                           opt_subcategory: str,
                           task_order: str) -> str:
        '''
        Class method to determine commodity team based on supplied parameters.

        Args:
            tlp_ind (str): Binary Y/N to determine if locally procured
            category (str): Product category
            opt_subcategory (str): Subcategory based on the Order Promising Tool (OPT)
            task_order (str): Task order

        returns:
            commodity_team (str): commodity team
        '''

        commodity_team = "unknown"

        if tlp_ind == "Y":
            commodity_team = "DCP"
        elif opt_subcategory in ['AL Generic', 'ASAQ']:
            commodity_team = 'ACTs'
        elif (opt_subcategory in ['Artesunate Suppositories', 'Artemether Injectables', 'Other Malaria Pharmaceuticals',
                                  'Malaria Pharmaceuticals Default', 'Quinine Tablets', 'Quinine Injectables', 'SP', 'SPAQ']) \
                or (task_order == 'TO2' and category == 'Essential Medicines'):
            commodity_team = 'TO2 Pharma'
        else:
            if category in _POW_MAP_PRODUCT_CAT_2_COMMODITY_TEAM:
                commodity_team = _POW_MAP_PRODUCT_CAT_2_COMMODITY_TEAM[category]
            else:
                commodity_team = 'Lab'

            if commodity_team == 'Lab' and task_order == 'TO2':
                commodity_team = 'TO2 Lab'

        return commodity_team

    def add_catalog_info(self,
                         order_df: pd.DataFrame,
                         *args: tuple,
                         rename: Optional[Mapping[str, str]] = None,
                         commodity_team: Optional[bool] = True,
                         item_key: Optional[str] = 'ITEM_ID'
                         ) -> pd.DataFrame:
        '''
        Adds catalog information to the orders DataFrame utilizing ITEM_ID as primary key.

        Args:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB
            *args (tuple): Variable length iterable to include fields in Order DF from Catalog DF
            commodity_team (boolean): Defaults to True. Returns Commodity Team field

        returns:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB with catalog info added.
        '''

        cat_df = self.get_catalog()

        # Adds required fields from catalog & drop duplicates
        all_args = [item_key] + [arg for arg in args] + ['COMMODITY_SUBCAT_SHORT_DESC',
                                                         'PRODUCT_NAME', 'OPT_SUBCATEGORY']
        all_args = list(dict.fromkeys(all_args))

        cat_df = cat_df[all_args]

        order_df = order_df.merge(cat_df, on=item_key, how='left')

        added_fields = [arg for arg in all_args if arg != item_key and arg in args]

        if commodity_team:
            order_df['COMMODITY_TEAM'] = order_df.apply(lambda row: self.get_commodity_team(row['TLP_IND'], row['COMMODITY_SUBCAT_SHORT_DESC'], row['OPT_SUBCATEGORY'], row['TASK_ORDER']), axis=1)
            added_fields.append('COMMODITY_TEAM')

        order_df.drop(columns=[arg for arg in all_args if arg != "ITEM_ID" and arg not in args], inplace=True)

        if rename is not None:
            order_df.rename(columns=rename, inplace=True)
            added_fields = [rename[f] if f in rename.keys() else f for f in added_fields]

        for f in added_fields:
            self.log.debug(f'{f} added to Purchase Orders')

        return order_df

    def add_supplier_info(self,
                          order_df: pd.DataFrame,
                          *args: tuple,
                          rename: Optional[Mapping[str, str]] = None,
                          supplier_key: Optional[str] = 'SUPPLIER_KEY'
                          ) -> str:
        '''
        Adds supplier information to the orders DataFrame utilizing SUPPLIER_KEY as primary key.

        Args:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB
            *args (tuple): Variable length iterable to include fields in Order DF from Supplier DF
            supplier_key (str): Defaults to supplier key field. Modify if table key changes

        returns:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB with supplier fields added.
        '''

        supplier_df = self.get_suppliers()

        supplier_df = supplier_df[[arg for arg in args if arg != supplier_key] + [supplier_key]].copy()

        added_fields = [arg for arg in args if arg != supplier_key]

        order_df = order_df.merge(supplier_df, on=supplier_key, how='left')

        if rename is not None:
            order_df.rename(columns=rename, inplace=True)
            added_fields = [rename[f] if f in rename.keys() else f for f in added_fields]

        for f in added_fields:
            self.log.debug(f'{f} added to Purchase Orders')

        return order_df

    def add_status_info(self,
                        order_df: pd.DataFrame,
                        *args: tuple,
                        rename: Optional[Mapping[str, str]] = None,
                        status_key: Optional[str] = 'STATUS_KEY'
                        ) -> str:
        '''
        Adds status information to the orders DataFrame utilizing STATUS_KEY as primary key.

        Args:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB
            *args (tuple): Variable length iterable to include fields in Order DF from Status DF
            status_key (str): Defaults to status key field. Modify if table key changes

        returns:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB with status fields added.
        '''

        status_df = self.get_status()

        status_df = status_df[[arg for arg in args if arg != status_key] + [status_key]].copy()

        added_fields = [arg for arg in args if arg != status_key]

        order_df = order_df.merge(status_df, on=status_key, how='left')

        if rename is not None:
            order_df.rename(columns=rename, inplace=True)
            added_fields = [rename[f] if f in rename.keys() else f for f in added_fields]

        for f in added_fields:
            self.log.debug(f'{f} added to Purchase Orders')

        return order_df

    def add_recipient_info(self,
                           order_df: pd.DataFrame,
                           *args: tuple,
                           rename: Optional[Mapping[str, str]] = None,
                           recipient_key: Optional[str] = 'RECIPIENT_KEY'
                           ) -> str:
        '''
        Adds recipient information to the orders DataFrame utilizing RECIPIENT_KEY as primary key.

        Args:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB
            *args (tuple): Variable length iterable to include fields in Order DF from Recipient DF
            recipient_key (str): Defaults to recipient key field. Modify if table key changes

        returns:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB with recipient fields added.
        '''

        recipient_df = self.get_recipients()

        recipient_df = recipient_df[[arg for arg in args if arg != recipient_key] + [recipient_key]].copy()

        added_fields = [arg for arg in args if arg != recipient_key]

        order_df = order_df.merge(recipient_df, on=recipient_key, how='left')

        if rename is not None:
            order_df.rename(columns=rename, inplace=True)
            added_fields = [rename[f] if f in rename.keys() else f for f in added_fields]

        for f in added_fields:
            self.log.debug(f'{f} added to Purchase Orders')

        return order_df

    def add_order_shipment_info(self,
                                order_df: pd.DataFrame,
                                *args: tuple,
                                rename: Optional[Mapping[str, str]] = None,
                                ship_key: Optional[str] = 'ORDER_KEY'
                                ) -> str:
        '''
        Adds shipment qty to the orders DataFrame utilizing ORDER_KEY as primary key.

        Args:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB
            *args (tuple): Variable length iterable to include fields in Order DF from Recipient DF
            order_key (str): Defaults to order key field. Modify if table key changes

        returns:
            order_df (pd.DataFrame): Order dataframe from orders table in Azure SQL DB with shipment qty added.
        '''

        order_shipment_df = self.get_order_shipments()

        order_shipment_df = order_shipment_df[[arg for arg in args if arg != ship_key] + [ship_key]].copy()

        for col in order_shipment_df.columns:
            if col[-4:] == 'DATE' and order_shipment_df[col].dtype != 'datetime64[ns]':
                order_shipment_df.loc[:, col] = pd.to_datetime(order_shipment_df[col])

        order_shipment_df = order_shipment_df.groupby([ship_key]).agg({key: np.max if key[-4:] == 'DATE' else np.sum for key in args})

        added_fields = [arg for arg in args if arg != ship_key]

        order_df = order_df.merge(order_shipment_df, on=ship_key, how='left')

        if rename is not None:
            order_df.rename(columns=rename, inplace=True)
            added_fields = [rename[f] if f in rename.keys() else f for f in added_fields]

        for f in added_fields:
            self.log.debug(f'{f} added to Purchase Orders')

        return order_df


if __name__ == '__main__':
    root = dirname(abspath(__file__))
    ads_dao = ADS_DAO()
    # Get Order Data & add relevant table data
    order_df = ads_dao.get_orders()
    ads_po_df = ads_dao.add_catalog_info(order_df, 'COMMODITY_SUBCAT_SHORT_DESC', 'PRODUCT_NAME',
                                         rename={'COMMODITY_SUBCAT_SHORT_DESC': 'PRODUCT_CATEGORY'})

    ads_po_df = ads_dao.add_supplier_info(ads_po_df, 'PARENT_PROFILE_NAME', 'COUNTRY_CD',
                                          rename={'PARENT_PROFILE_NAME': 'SUPPLIER_NAME',
                                                  'COUNTRY_CD': 'SUPPLIER_COUNTRY'})

    ads_po_df = ads_dao.add_recipient_info(ads_po_df, 'COMPANY', 'COUNTRY_CD',
                                           rename={'COMPANY': 'CUSTOMER',
                                                   'COUNTRY_CD': 'CUSTOMER_COUNTRY'})

    ads_po_df = ads_dao.add_order_shipment_info(ads_po_df, 'PICK_UP_DATE',
                                                rename={'PICK_UP_DATE': 'CARGO_PICKED_UP_DATE'})

    # Some status codes are duplicated. This may cause duplicate order line warning.
    ads_po_df = ads_dao.add_status_info(ads_po_df, 'STATUS_NAME')
